=== Wps Testimonials ===
Contributors: vinit-sharma , webplanetsoft
Donate link: https://www.linkedin.com/in/iamvinitsharma
Tags:  testimonials , testimonials carousel , responsive testimonial
Requires at least: 3.3
Tested up to: 4.9.8
Stable tag: 0.37
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html


Wps Testimonials


== Description ==

Wps Testimonials (Wps Testimonials best plugin to display Testimonials and testimonials carousel)

Perfect plugin to display  testimonials carousel and testimonials  control testimonials from    WP admin. You can easily  add , delete, edit testimonials  and control testimonials carousel.
== Installation ==

== Frequently Asked Questions ==

Ques : Is this testimonials carousel

Ans  : Yes


== Screenshots ==
1. Testimonials Carousel Frontend
2. Testimonials Setting Panel
3. Testimonials Shortcode
4. Simple Testimonials Showcase


== Upgrade Notice ==


== Changelog ==

Wps Testimonials 1.0.0

* Display Testimonials carousel