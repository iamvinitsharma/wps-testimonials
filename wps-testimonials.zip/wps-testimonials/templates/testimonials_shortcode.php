<?php if ( ! defined( 'ABSPATH' ) ) exit; ?>
<div class="wrap-wps_testimonials">
  <h1 class="wps_heading">Testimonials Shortcode </h1>
 <p>Open a <a href="mailto:iamvinitsharma@gmail.com" target="_blank">support ticket</a> if you need help.</p>
 <h3>Testimonial Slider Shortcode   </h3> 
 <p> [wps_tc_testimonials_slider]  </p>

</div>