 <?php if ( ! defined( 'ABSPATH' ) ) exit; ?>
 <?php
  $wps_tc_testimonials_width = $aVars['wps_tc_testimonials_width'];
  $wps_tc_testimonials_countery = $aVars['wps_tc_testimonials_countery'];
  $wps_tc_testimonials_image_size = $aVars['wps_tc_testimonials_image_size'];

             $args = array( 'post_type' => 'wps_tc_testimonials', 'posts_per_page' => 6,);
             
           
              $loop = new WP_Query( $args );
              
              ?>

				<div class="contaissner wpstestimonials" style="width:<?php echo $wps_tc_testimonials_width; ?>">

          		<div class="wrapperslider">
				<div class="center">

              <?php

                while ( $loop->have_posts() ) : $loop->the_post();
                	$currentpostid = get_the_id();
                	$metass = get_post_meta( $currentpostid, 'testimonials_fields', true ); 

               ?>
               <div>

               <div class="featuredimage"> 
               	<img  style="width: <?php echo   $wps_tc_testimonials_image_size; ?>; height:  <?php echo   $wps_tc_testimonials_image_size; ?>; " src="<?php the_post_thumbnail_url('full'); ?>">
               </div>
               <div class="nametitle"> <?php the_title(); ?></div>
               <?php 

$terms = get_the_terms( get_the_ID(), 'testimonials_countery' );
                         
if ( $terms && ! is_wp_error( $terms ) ) : 
 
    $draught_links = array();
 
    foreach ( $terms as $term ) {
        $draught_links[] = $term->name;
    }
                         
    $countery = join( ", ", $draught_links );
  
    ?>
 
   
<?php endif;  
               if ($wps_tc_testimonials_countery=='yes') {
               ?>
                  <div class="companyname"><?php echo $countery; ?> </div>
               <?php
               }
               ?>
               <div class="contenteps"><?php the_content(); ?> </div>
              
               </div>


           <?php  endwhile; ?>
			</div>
			</div>
			</div>

    <?php wp_reset_query(); ?> 
